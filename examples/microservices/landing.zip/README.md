# Static website package

Open index.html locally for a preview.
Client approval and deployment authorization are required before hosting. After review, extract files to an approved static host (Cloudflare Pages, GitHub Pages, etc.). Configure DNS/domain separately and verify the live URL, links and accessibility.
No backend, contact form submission, or payment processing is configured for this static-only package.
Analytics, deployment and custom domain are never configured by this builder alone.
When no contact form is enabled, contact links use mailto.
